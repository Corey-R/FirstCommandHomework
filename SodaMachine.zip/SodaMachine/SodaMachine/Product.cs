﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SodaMachine
{
    public class Product
    {
        public string Code { get; set; }        
        public bool ValidCode { get; set; } = false;
        // Added products to Soda list using constructor created in Soda.cs
        public List<Soda> Sodas { get; set; } = new List<Soda>()
            {
                new Soda("A1", "Strawberry Valley", "12 ounce can", 80, 12),
                new Soda("A2", "Cherry Blast", "12 ounce can", 80, 8),
                new Soda("B1", "Artic Freeze", "20 ounce bottle", 150, 9),
                new Soda("B2", "Jammin' Grape", "20 ounce bottle", 150, 5),
                new Soda("A3", "Wildberry Galaxy", "12 ounce can", 80, 1),
                new Soda("A4", "Phoenix Ale", "12 ounce can", 80, 0),
                new Soda("B3", "Wavy Waters", "24 ounce bottle", 160, 3),
                new Soda("B4", "Spooky Cola", "20 oz bottle", 150, 7),
            };
        SodaMachine machine = new SodaMachine();
        /* This method does the following: 
         * Displays a list of all current sodas in the machine
         * Prompts user to enter corresponding code to purchase
         * While loop calls method that verifies user's input to a code
        */
        public void SelectOption(int cents)
        {                        
            Console.WriteLine("\nHere are your options:\n");
            foreach (var soda in Sodas)
            {
                Console.WriteLine("Code: {0} | {1} | {2} | {3} cents | {4} left", soda.Code, soda.Flavor, soda.Size, soda.Price, soda.Available);
            }
            while (!ValidCode)
            {
                Console.Write("\nPlease make your selection by entering the code here: ");
                string select = Console.ReadLine().ToUpper();
                CheckCode(select, cents); // Calls method passing in user's code and balance
            }            
        }
        // This method uses a switch statement to check if user's input matches a product code.
        // If a match, it calls PurchaseSoda() method
        // If no match, the while loop starts again from SelectOption() method.
        public void CheckCode(string code, int coins)
        {
            
            switch (code)
            {
                case "A1": ValidCode = true; PurchaseSoda(code, coins);  break;
                case "A2": ValidCode = true; PurchaseSoda(code, coins);  break;
                case "A3": ValidCode = true; PurchaseSoda(code, coins);  break;
                case "A4": ValidCode = true; PurchaseSoda(code, coins);  break;
                case "B1": ValidCode = true; PurchaseSoda(code, coins);  break;
                case "B2": ValidCode = true; PurchaseSoda(code, coins);  break;
                case "B3": ValidCode = true; PurchaseSoda(code, coins);  break;
                case "B4": ValidCode = true; PurchaseSoda(code, coins);  break;
                default: Console.WriteLine("Invalid Code..");  break;
            }
        }
        /* This method does the following:
         * Checks if user has enough to purchase the selected soda
         * If they have enough:
           - Uses lambda function to find soda with user's matching code
           - Subtracts price of soda from user's balance
           - Dispenses their soda and change
           - Resets balance and subtracts 1 product from inventory
           - Program is returned to Program.cs
        * If they don't have enough:
           - They're asked to make another selection
           - If yes, while loop (!ValidCode) starts again from SelectOption() method
           - If no, user is refunded their balance in full and returned to Program.cs         
        */
        public void PurchaseSoda(string code, int currentBalance)
        {            
            Soda selectedSoda = Sodas.Find(x => x.Code == code);
            if (currentBalance >= selectedSoda.Price && selectedSoda.Available >= 1)
            {
                currentBalance -= selectedSoda.Price;
                Console.WriteLine("\nHere's your {0}! \nAnd here's your change of {1} cent(s).", 
                    selectedSoda.Flavor, currentBalance);
                currentBalance = 0;
                selectedSoda.Available--;
            }
            else
            {
                Console.WriteLine("Not enough coins or item is sold out :(.");
                bool validAnswer = false;
                while (!validAnswer)
                {
                    Console.Write("Make another selection? (y/n): ");
                    string answer = Console.ReadLine().ToLower();
                    if (answer == "y") { ValidCode = false; validAnswer = true; }
                    else if (answer == "n") { machine.GetRefund(currentBalance); validAnswer = true; }
                    else Console.WriteLine("\nPlease enter 'y' or 'n'..");
                }               
            }                       
        }
    }
}
