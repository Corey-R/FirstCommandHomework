﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SodaMachine
{
    public class Program
    {
        static void Main(string[] args)
        {
            // INTRODUCTION
            Console.WriteLine("Welcome to our Soda Factory!");
            Console.WriteLine("---------------------------------\n");
            Console.WriteLine("Here, you'll be able to select a refreshing beverage \nfrom our soda machine...for the right price, of course.\n" +
                "press Enter to continue..");
            Console.ReadLine();

            // Instantiate SodaMachine object and set int variable to 0
            SodaMachine machine = new SodaMachine();
            int insertedCoins = 0;            
            
            /*
             This block of code does the following: 
            * Create while loop that ends once user chooses not to add more coins
            * Takes user's input, casts to int, checks for negative numbers,
              - catches format or any other errors
            * Starts SodaMachine process passing in user's coins as an argument
            */
            while(!machine.HasEnough)
            {                              
                Console.Write("How much would you like to insert? \n(e.g. 50 = 50 cents): ");
                try
                {
                    insertedCoins = Convert.ToInt32(Console.ReadLine());
                    if (insertedCoins < 0)
                    {
                        Console.WriteLine("\n\nUnfortunately, I must now call my golumpa wumpas to escort you \n" +
                        "off the premises..Good Day!");
                        Console.ReadLine();
                        return;
                    }
                    else machine.Process(insertedCoins); // See SodaMachine.cs
                }
                catch (FormatException ex)
                {
                    Console.WriteLine("\nError: {0} \nYou must enter a whole number..\n", ex.Message);
                }    
                catch (Exception ex)
                {
                    Console.WriteLine("An unexpected error has occurred. \n{0}", ex.Message);
                }
            }            
            Console.WriteLine("Thanks for stopping by, have a great day!");
            Console.ReadLine();
            
           
        }
    }
}
