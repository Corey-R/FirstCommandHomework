﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SodaMachine
{
    public class SodaMachine
    {
        // Creating a constructor that gives Balance attribute a value of 0
        public SodaMachine()
        {
            Balance = 0;
        }
        public int Balance { get; set; }
        public bool HasEnough { get; set; } = false;
        const int sodaPrice = 80;

        // Starts the implementation for machine.Process(insertedCoins)...
        // from Program.cs
        public void Process(int currentBalance)
        {
            Balance += currentBalance; // Adds user's input to Balance        
            Console.WriteLine("Your balance is: {0} cent(s).", Balance);
            bool validAnswer = false;
            // Similar to Program.cs while loop
            // User adds more coins until they say no using 'n'            
            while (!validAnswer)
            {
                Console.Write("\nWould you like to add more before making " +
               "your selection? ('y' = yes, 'n' = no) \nNOTE: must have at least 80 cents: ");
                string response = Console.ReadLine().ToLower();

                if (response == "y")
                {
                    HasEnough = false;
                    validAnswer = true;
                }
                else if (response == "n")
                {
                    HasEnough = true;
                    validAnswer = true;
                    CanPurchase(); // Calls method (See CanPurchase() below
                }
                else Console.WriteLine("Please enter 'y' for yes or 'n' for no..\n");
            }                                    
        }
        /* This method does the following:
         * Checks if user has enough to purchase the cheapest soda.
         * Calls product method if they have enough
         * If they don't have enough, a while loop allows user to add more
         * If the user refuses to add more coins, they will be refunded their balance
        */
        public void CanPurchase()
        {
            if (Balance >= sodaPrice)
            {
                Product selection = new Product();
                selection.SelectOption(Balance); // See Products.cs           
            }
            else
            {
                bool validAnswer = false;
                Console.WriteLine("It seems you don't have enough to purchase a soda :(");
                while (!validAnswer)
                {
                    Console.Write("\nAdd more coins? (y/n): ");
                    string answer = Console.ReadLine().ToLower();
                    // NOTE: if HasEnough is false, the first while loop starts again (See Process())
                    if (answer == "y") { HasEnough = false; validAnswer = true; }
                    else if (answer == "n") { GetRefund(Balance); validAnswer = true; } // See GetRefund(int currentBalance)
                    else Console.WriteLine("\nPlease enter 'y' or 'n'...");
                }                
            }                                                 
        }
        // This method returns user's money
        // NOTE: currentBalance - currentBalance could reset too
        public void GetRefund(int currentBalance)
        {
            Console.WriteLine("\nYou were refunded {0} cent(s)!", currentBalance);
            currentBalance = 0;
        }
    }
}
