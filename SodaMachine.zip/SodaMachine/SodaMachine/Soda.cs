﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SodaMachine
{
    public class Soda
    {
        public Soda(string code, string flavor, string size, int price, int available)
        {
            this.Code = code;
            this.Flavor = flavor;
            this.Size = size;
            this.Price = price;
            this.Available = available;
        }
        public string Code { get; set; }
        public string Flavor { get; set; }
        public string Size { get; set; }
        public int Price { get; set; }
        public int Available { get; set; }                       
    }    
}
